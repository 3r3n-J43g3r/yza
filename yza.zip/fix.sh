cd
cd
cd AllHackingTools
cd Tool
chmod +x *
cp * /data/data/com.termux/files/usr/bin 
cd
