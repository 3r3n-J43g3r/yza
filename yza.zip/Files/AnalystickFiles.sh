cd
cd 
cd AllHackingTools
pip2 install termcolor
git clone https://github.com/floriankunushevci/rang3r
cd
cd AllHackingTools
git clone https://github.com/TechnicalMujeeb/TM-scanner.git 
cd TM-scanner 
chmod +x * sh install.sh
cd
cd
cd AllHackingTools
git clone https://github.com/Gameye98/AstraNmap
cd
cd
cd AllHackingTools
