
print(f"[\x1b[38;5;9mSYSTEM\x1b[38;5;255m] \x1b[38;5;227mMade by your precious Yza")

